// event-groups module removed — kept as a no-op to avoid import errors elsewhere
export function initEventGroups() {
  // This module intentionally left blank after removing the UI list per user request.
}